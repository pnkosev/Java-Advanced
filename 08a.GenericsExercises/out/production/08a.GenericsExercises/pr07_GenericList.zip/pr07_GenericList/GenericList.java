package pr07_GenericList;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class GenericList<T extends Comparable<T>> {
    private List<T> collection;

    public GenericList() {
        this.collection = new ArrayList<>();
    }

    public void add(T element) {
        this.collection.add(element);
    }

    public T remove(int index) {
        if (index < this.collection.size()) {
            return this.collection.remove(index);
        }
        return null;
    }

    public boolean contains(T element) {
        return this.collection.contains(element);
    }

    public void swap(int indexOne, int indexTwo) {
        T elOne = this.collection.get(indexOne);
        T elTwo = this.collection.get(indexTwo);
        this.collection.add(indexOne, elTwo);
        this.collection.remove(elOne);
        this.collection.add(indexTwo, elOne);
        this.collection.remove(indexTwo + 1);
    }

    public int countGreaterThan(T element) {
        int[] count = {0};

        this.collection.forEach(e -> {
            if (e.compareTo(element) > 0) {
                count[0]++;
            }
        });

        return count[0];
    }

    public T getMin() {
        return this.collection.stream().min(Comparable::compareTo).orElse(null);
    }

    public T getMax() {
        return this.collection.stream().max(Comparable::compareTo).orElse(null);
    }

    public void sort() {
        Collections.sort(this.collection);
    }

    public void print() {
        StringBuilder sb = new StringBuilder();

        for (T element: this.collection) {
            sb.append(element)
                    .append(System.lineSeparator());
        }

        System.out.println(sb.toString());
    }
}

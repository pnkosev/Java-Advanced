package pr07_GenericList;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        GenericList<String> list = new GenericList<>();

        String line;

        while (!(line = scanner.nextLine()).equals("END")) {
            String[] input = line.split("\\s+");
            String command = input[0].toLowerCase();

            switch (command) {
                case "add":
                    list.add(input[1]);
                    break;
                case "remove":
                    list.remove(Integer.parseInt(input[1]));
                    break;
                case "greater":
                    System.out.println(list.countGreaterThan(input[1]));
                    break;
                case "min":
                    System.out.println(list.getMin());
                    break;
                case "max":
                    System.out.println(list.getMax());
                    break;
                case "swap":
                    list.swap(Integer.parseInt(input[1]), Integer.parseInt(input[2]));
                    break;
                case "contains":
                    System.out.println(list.contains(input[1]));
                    break;
                case "sort":
                    list.sort();
                    break;
                case "print":
                    list.print();
                    break;
            }
        }
    }
}

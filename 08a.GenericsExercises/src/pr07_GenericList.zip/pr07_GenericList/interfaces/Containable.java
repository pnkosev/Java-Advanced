package pr07_GenericList.interfaces;

public interface Containable<T> {
    boolean contains(T element);
}

package pr07_GenericList.interfaces;

public interface Removable<T> {
    T remove(int index);
}

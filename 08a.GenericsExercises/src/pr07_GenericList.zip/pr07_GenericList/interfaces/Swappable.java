package pr07_GenericList.interfaces;

public interface Swappable {
    void swap(int indexOne, int indexTwo);
}

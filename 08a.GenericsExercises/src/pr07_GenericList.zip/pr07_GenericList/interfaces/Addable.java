package pr07_GenericList.interfaces;

public interface Addable<T> {
    void add(T element);
}

package pr07_GenericList.interfaces;

public interface Printable {
    void print();
}
